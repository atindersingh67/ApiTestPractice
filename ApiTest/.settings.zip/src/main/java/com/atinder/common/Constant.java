package com.atinder.common;

public class Constant {

	public static enum USER_DISCOUNT {
		EMPLOYEE_DISCOUNT(30), AFFILIATE_DISCOUNT(10), TWO_YEARS_DISCOUNT(5);

		private final int value;

		USER_DISCOUNT(final int newValue) {
			value = newValue;
		}

		public int getValue() {
			return value;
		}
	}

	public static enum USER_TYPE {
		EMPLOYEE("EMPLOYEE"), AFFILIATE("AFFILIATE");
		private final String value;

		USER_TYPE(final String newValue) {
			value = newValue;
		}

		public String getValue() {
			return value;
		}
	}

	public static enum UNDISCOUNTED_TYPES {
		GROCERIES("GROCERIES");
		private final String value;

		UNDISCOUNTED_TYPES(final String newValue) {
			value = newValue;
		}

		public String getValue() {
			return value;
		}
	}

	public static final int DURATION_FOR_DISCOUNT = 2;
	public static final int DISCOINT_VALUE = 5;
	public static final int DISCOINT_ON = 100;
}
