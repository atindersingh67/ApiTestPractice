package com.atinder.service;

import com.atinder.domain.User;

/**
 * @author atindersingh
 *
 */
public interface IDiscountService {
	double calucateDiscount(User user);
}
