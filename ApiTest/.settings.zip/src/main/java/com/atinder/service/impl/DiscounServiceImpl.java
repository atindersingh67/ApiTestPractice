/**
 * 
 */
package com.atinder.service.impl;

import org.springframework.stereotype.Service;

import com.atinder.common.Constant;
import com.atinder.common.Constant.UNDISCOUNTED_TYPES;
import com.atinder.common.Constant.USER_DISCOUNT;
import com.atinder.common.Constant.USER_TYPE;
import com.atinder.domain.User;
import com.atinder.service.IDiscountService;

/**
 * @author atindersingh
 *
 */
@Service
public class DiscounServiceImpl implements IDiscountService {

	@Override
	public double calucateDiscount(User user) {
		// TODO Auto-generated method stub
		if(user.getItem().getType().equalsIgnoreCase(UNDISCOUNTED_TYPES.GROCERIES.getValue())){
			return getOtherDiscount(user);
		}
		return getUserDiscount(user) + getOtherDiscount(user);
	}

	private double getUserDiscount(User user) {
		if (user.getType().equalsIgnoreCase(USER_TYPE.EMPLOYEE.getValue())) {
			return calulateDiscount(user.getBill(), USER_DISCOUNT.EMPLOYEE_DISCOUNT.getValue());
		} else if (user.getType().equalsIgnoreCase(USER_TYPE.AFFILIATE.getValue())) {
			return calulateDiscount(user.getBill(), USER_DISCOUNT.AFFILIATE_DISCOUNT.getValue());
		} else if (user.getDuration() > Constant.DURATION_FOR_DISCOUNT) {
			return calulateDiscount(user.getBill(), USER_DISCOUNT.TWO_YEARS_DISCOUNT.getValue());
		} else {
			return 0;
		}

	}

	private double getOtherDiscount(User user) {
		return ((int)(user.getBill() / Constant.DISCOINT_ON)) * Constant.DISCOINT_VALUE;

	}

	public static double calulateDiscount(double amt, double dis) {
		return (dis / 100) * amt;
	}
}
