package com.atinder.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.atinder.common.Constant.USER_TYPE;
import com.atinder.domain.Item;
import com.atinder.domain.User;

@RunWith(SpringRunner.class)
@WebMvcTest(DiscountController.class)
public class DiscountControllerTest {
	@MockBean
	private DiscountController discountController;
	@Autowired
	private MockMvc mvc;

	@Test
	public void getArrivals() throws Exception {
		User user = new User();
		user.setBill(990);
		user.setCreatedDate(new Date());
		user.setType(USER_TYPE.EMPLOYEE.getValue());
		user.setItem(new Item("Others"));
		discountController.calculateDiscount(user);
		
		
		/*post(uri)
		  mvc.perform(post("ddd/")
	               .contentType(APPLICATION_JSON))
	               .andExpect(status().isOk());
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/students/Student1/courses")
				.accept(MediaType.APPLICATION_JSON).content(user)
				.contentType(MediaType.APPLICATION_JSON);*/
	}
}
